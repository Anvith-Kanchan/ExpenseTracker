package com.anvith.expensetracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min

private data class Expense(
    val id: Long,
    val title: String,
    val category: String,
    val amount: Double,
    val date: Date = Date(),
    val payment: String = "UPI"
)

private val demoExpenses = listOf(
    Expense(1, "Dinner", "Food", 420.0, payment = "UPI"),
    Expense(2, "Metro", "Transport", 80.0, payment = "Card"),
    Expense(3, "Groceries", "Shopping", 1260.0, payment = "UPI"),
    Expense(4, "Coffee", "Food", 180.0, payment = "Cash")
)

private fun money(value: Double): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).format(value)
private fun dateText(date: Date): String = SimpleDateFormat("dd MMM", Locale.ENGLISH).format(date)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ExpenseTrackerApp() }
    }
}

@Composable
fun ExpenseTrackerApp() {
    var expenses by remember { mutableStateOf(demoExpenses) }
    var selectedTab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var showBudget by remember { mutableStateOf(false) }
    var darkMode by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = if (darkMode) androidx.compose.material3.darkColorScheme() else androidx.compose.material3.lightColorScheme()) {
        Scaffold(
            bottomBar = {
                BottomAppBar {
                    NavItem("Home", Icons.Default.Home, selectedTab == 0) { selectedTab = 0 }
                    NavItem("History", Icons.Default.CalendarMonth, selectedTab == 1) { selectedTab = 1 }
                    NavItem("Insights", Icons.Default.Analytics, selectedTab == 2) { selectedTab = 2 }
                    NavItem("Settings", Icons.Default.Settings, selectedTab == 3) { selectedTab = 3 }
                }
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, shape = CircleShape) {
                    Icon(Icons.Default.Add, contentDescription = "Add expense")
                }
            }
        ) { padding ->
            when (selectedTab) {
                0 -> Dashboard(expenses, padding, onBudget = { showBudget = true })
                1 -> History(expenses, padding, onDelete = { id -> expenses = expenses.filterNot { it.id == id } })
                2 -> Insights(expenses, padding)
                3 -> SettingsScreen(darkMode, { darkMode = it }, padding)
            }
        }

        if (showAdd) {
            AddExpenseDialog(onDismiss = { showAdd = false }) { expense ->
                expenses = listOf(expense) + expenses
                showAdd = false
            }
        }
        if (showBudget) BudgetDialog(onDismiss = { showBudget = false })
    }
}

@Composable
private fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    androidx.compose.material3.NavigationBarItem(selected = selected, onClick = onClick, icon = { Icon(icon, null) }, label = { Text(label) })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Dashboard(expenses: List<Expense>, padding: androidx.compose.foundation.layout.PaddingValues, onBudget: () -> Unit) {
    val total = expenses.sumOf { it.amount }
    val budget = 15000.0
    val percent = min(1.0, total / budget).toFloat()
    val food = expenses.filter { it.category == "Food" }.sumOf { it.amount }
    val shopping = expenses.filter { it.category == "Shopping" }.sumOf { it.amount }
    val transport = expenses.filter { it.category == "Transport" }.sumOf { it.amount }
    val categories = listOf("Food" to food, "Shopping" to shopping, "Transport" to transport).filter { it.second > 0 }

    Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
        SmallTopAppBar(title = { Text("Good morning", fontWeight = FontWeight.Bold) }, actions = {
            IconButton(onClick = onBudget) { Icon(Icons.Default.AttachMoney, "Budget") }
        })
        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp)) {
                        Text("Spent this month", style = MaterialTheme.typography.labelLarge)
                        Text(money(total), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 5.dp))
                        Text("${money(budget - total)} left of ${money(budget)} budget", color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .72f))
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(progress = { percent }, modifier = Modifier.fillMaxWidth().height(8.dp), trackColor = MaterialTheme.colorScheme.surfaceVariant)
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatCard("Today", money(420.0), Icons.Default.CalendarMonth, Modifier.weight(1f))
                    StatCard("Daily avg", money(if (expenses.isEmpty()) 0.0 else total / 4.0), Icons.Default.Analytics, Modifier.weight(1f))
                }
            }
            item { Text("Spending by category", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(categories) { (name, value) ->
                val share = if (total == 0.0) 0f else (value / total).toFloat()
                CategoryRow(name, value, share)
            }
            item { Text("Recent expenses", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp)) }
            items(expenses.take(4), key = { it.id }) { ExpenseRow(it) }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(16.dp)) {
            Icon(icon, null, modifier = Modifier.size(22.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, style = MaterialTheme.typography.labelMedium)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
    }
}

@Composable
private fun CategoryRow(name: String, value: Double, share: Float) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(MaterialTheme.colorScheme.secondaryContainer, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Category, null) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(name, fontWeight = FontWeight.SemiBold)
                Text(money(value), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { share }, modifier = Modifier.fillMaxWidth().height(7.dp))
        }
    }
}

@Composable
private fun ExpenseRow(expense: Expense) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).background(MaterialTheme.colorScheme.surfaceVariant, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.AttachMoney, null) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(expense.title, fontWeight = FontWeight.SemiBold)
            Text("${expense.category} • ${dateText(expense.date)} • ${expense.payment}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(money(expense.amount), fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun History(expenses: List<Expense>, padding: androidx.compose.foundation.layout.PaddingValues, onDelete: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    val categories = listOf("All", "Food", "Shopping", "Transport", "Bills")
    val filtered = expenses.filter { (query.isBlank() || it.title.contains(query, ignoreCase = true)) && (category == "All" || it.category == category) }
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
        SmallTopAppBar(title = { Text("Expenses", fontWeight = FontWeight.Bold) })
        OutlinedTextField(value = query, onValueChange = { query = it }, leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Search expenses") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 12.dp)) { categories.forEach { c -> FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) }) } }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            items(filtered, key = { it.id }) { expense ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    ExpenseRow(expense)
                    IconButton(onClick = { onDelete(expense.id) }) { Icon(Icons.Default.DeleteOutline, "Delete") }
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun Insights(expenses: List<Expense>, padding: androidx.compose.foundation.layout.PaddingValues) {
    val total = expenses.sumOf { it.amount }
    val byCategory = expenses.groupBy { it.category }.mapValues { it.value.sumOf(Expense::amount) }.toList().sortedByDescending { it.second }
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp)) {
        SmallTopAppBar(title = { Text("Insights", fontWeight = FontWeight.Bold) })
        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { InsightCard("Total tracked", money(total), "Across ${expenses.size} expenses") }
            item { InsightCard("Top category", byCategory.firstOrNull()?.first ?: "—", byCategory.firstOrNull()?.let { money(it.second) } ?: "No data") }
            item { Text("Where your money goes", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(byCategory) { (name, value) -> CategoryRow(name, value, if (total == 0.0) 0f else (value / total).toFloat()) }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun InsightCard(title: String, big: String, detail: String) {
    Card(shape = RoundedCornerShape(22.dp)) { Column(Modifier.fillMaxWidth().padding(20.dp)) { Text(title, style = MaterialTheme.typography.labelLarge); Text(big, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold); Text(detail, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
}

@Composable
private fun SettingsScreen(darkMode: Boolean, onDarkMode: (Boolean) -> Unit, padding: androidx.compose.foundation.layout.PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
        SmallTopAppBar(title = { Text("Settings", fontWeight = FontWeight.Bold) })
        Card(shape = RoundedCornerShape(22.dp)) { Column(Modifier.fillMaxWidth().padding(18.dp)) { Text("Appearance", fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("Dark mode"); androidx.compose.material3.Switch(checked = darkMode, onCheckedChange = onDarkMode) } } }
        Spacer(Modifier.height(14.dp))
        AssistChip(onClick = {}, label = { Text("Local-only data") }, leadingIcon = { Icon(Icons.Default.Settings, null) })
        Spacer(Modifier.height(8.dp))
        Text("Your expenses stay on this device. No account or cloud sync is required.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun AddExpenseDialog(onDismiss: () -> Unit, onSave: (Expense) -> Unit) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Food") }
    var payment by remember { mutableStateOf("UPI") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add expense") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Amount") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("What did you spend on?") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("Food", "Shopping", "Transport").forEach { c -> FilterChip(category == c, { category = c }, label = { Text(c) }) } }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("UPI", "Card", "Cash").forEach { p -> FilterChip(payment == p, { payment = p }, label = { Text(p) }) } }
        }
    }, confirmButton = { Button(onClick = { val v = amount.toDoubleOrNull(); if (v != null && v > 0 && title.isNotBlank()) onSave(Expense(System.currentTimeMillis(), title.trim(), category, v, payment = payment)) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
private fun BudgetDialog(onDismiss: () -> Unit) {
    var budget by remember { mutableStateOf("15000") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Monthly budget") }, text = { OutlinedTextField(value = budget, onValueChange = { budget = it }, label = { Text("Budget (₹)") }, singleLine = true) }, confirmButton = { Button(onClick = onDismiss) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}
